using System.Diagnostics;
using System.Text;
using MiniERP.Domain.Clientes;
using MiniERP.Domain.Compras;
using MiniERP.Domain.Finanzas;
using MiniERP.Domain.Inventario;
using MiniERP.Domain.Shared;
using MiniERP.Domain.Ventas;
using Piloto;

// =====================================================================================
//  PILOTO SIMULADO — Colmado La Esperanza, Moca — 20 dias de operacion
//  Ejecuta el codigo de dominio REAL de MiniERP. No reimplementa ninguna regla.
// =====================================================================================

var rnd = new Random(20260729);          // semilla fija: la corrida es reproducible
var libro = new Libro();
var dia0 = new DateTime(2026, 6, 1, 8, 0, 0, DateTimeKind.Utc);
var bitacora = new List<string>();
var incidencias = new List<(string Id, string Sev, string Titulo, string Detalle)>();
var casos = new List<(string Id, string Caso, string Esperado, string Obtenido, bool Ok)>();
var opsPorDia = new Dictionary<int, Dictionary<string, int>>();
int totalOps = 0;

void Log(string s) => bitacora.Add(s);
void Op(int dia, string tipo)
{
    totalOps++;
    if (!opsPorDia.TryGetValue(dia, out var d)) opsPorDia[dia] = d = new();
    d[tipo] = d.GetValueOrDefault(tipo) + 1;
}
void Caso(string id, string caso, string esperado, string obtenido, bool ok)
{
    casos.Add((id, caso, esperado, obtenido, ok));
    if (!ok) incidencias.Add((id, "ALTA", caso, $"esperado: {esperado} | obtenido: {obtenido}"));
}

var cronoTotal = Stopwatch.StartNew();

// -------------------------------------------------------------------- configuracion
Datos.Sembrar(libro, dia0);
Log($"Datos maestros: {libro.Productos.Count} productos, {libro.Clientes.Count} clientes, " +
    $"{libro.Proveedores.Count} proveedores, {libro.Categorias.Count} categorias, " +
    $"{libro.Unidades.Count} unidades, {libro.Secuencias.Count} secuencias NCF.");

int numFactura = 0, numCompra = 0;
int intentosCredito = 0, rechazosCredito = 0; decimal sumaRechazo = 0, dispRechazo = 0;
var tiemposVenta = new List<double>();
var tiemposRecepcion = new List<double>();
var verifPromedio = new List<(string Producto, decimal Esperado, decimal Obtenido, bool Ok)>();
var margenCongelado = new List<(string Ncf, decimal MargenAntes, decimal MargenDespues)>();

// ============================== helpers de operacion ==============================

Compra CrearCompra(int provId, DateTime fecha, CondicionPago cond, (Producto p, decimal cant, decimal costo)[] items)
{
    var c = new Compra
    {
        Id = libro.SiguienteId(),
        Numero = $"COM-{++numCompra:0000}",
        ProveedorId = provId,
        Fecha = fecha,
        Condicion = cond,
        Estado = EstadoCompra.Borrador,
        NcfProveedor = $"B01{rnd.Next(1, 99999999):00000000}",
        CreadoPor = Datos.Almacen
    };
    foreach (var (p, cant, costo) in items)
        c.Lineas.Add(new LineaCompra
        {
            Id = libro.SiguienteId(), CompraId = c.Id, ProductoId = p.Id,
            Descripcion = p.Descripcion, Cantidad = cant, CostoUnitario = costo,
            TasaItbis = p.TasaItbis, CreadoPor = Datos.Almacen
        });
    c.Recalcular();
    libro.Compras.Add(c);
    return c;
}

void RecibirCompra(Compra c, DateTime fecha)
{
    var prods = libro.PorId(c.Lineas.Select(x => x.ProductoId));
    // verificacion independiente del costo promedio ponderado, antes de recibir
    var esperados = new Dictionary<int, decimal>();
    foreach (var li in c.Lineas)
    {
        var p = prods[li.ProductoId];
        esperados[li.ProductoId] = (!p.ManejaInventario || p.Existencia <= 0)
            ? li.CostoUnitario
            : Math.Round((p.Existencia * p.Costo + li.Cantidad * li.CostoUnitario) / (p.Existencia + li.Cantidad), 4, MidpointRounding.AwayFromZero);
    }
    var cr = Stopwatch.StartNew();
    var movs = c.Recibir(prods, Datos.Almacen);
    cr.Stop();
    tiemposRecepcion.Add(cr.Elapsed.TotalMilliseconds);
    c.FechaRecepcion = fecha;                 // el dominio la fija con UtcNow; aqui se ajusta al dia simulado
    libro.RegistrarMovimientos(movs, fecha);
    foreach (var li in c.Lineas)
    {
        var p = prods[li.ProductoId];
        verifPromedio.Add((p.Descripcion, esperados[li.ProductoId], p.Costo, esperados[li.ProductoId] == p.Costo));
    }
    if (c.Condicion == CondicionPago.Credito)
    {
        var prov = libro.Proveedores.First(x => x.Id == c.ProveedorId);
        prov.BalanceActual += c.Total;        // unica linea que sube la deuda, como en CompraService
    }
}

Factura Vender(DateTime fecha, string cajero, Cliente cliente, CondicionPago cond,
               (Producto p, decimal cant)[] items, decimal recibido = 0)
{
    var tipo = cliente?.TipoComprobante ?? TipoComprobante.Consumo;
    var ncf = libro.AsignarNcf(tipo, fecha);
    if (ncf is null)
    {
        // sin comprobante disponible no hay venta; se reintenta con consumo, como haria el cajero
        ncf = libro.AsignarNcf(TipoComprobante.Consumo, fecha);
        tipo = TipoComprobante.Consumo;
        if (ncf is null) return null;
    }
    var f = new Factura
    {
        Id = libro.SiguienteId(),
        Numero = $"F-{++numFactura:00000}",
        TipoComprobante = tipo,
        ClienteId = cliente?.Id,
        ClienteNombre = cliente?.Nombre ?? "Cliente de contado",
        ClienteDocumento = cliente?.NumeroDocumento,
        Fecha = fecha,
        Condicion = cond,
        MontoRecibido = recibido,
        CreadoPor = cajero
    };
    foreach (var (p, cant) in items)
        f.Lineas.Add(new LineaFactura
        {
            Id = libro.SiguienteId(), FacturaId = f.Id, ProductoId = p.Id,
            Descripcion = p.Descripcion, Cantidad = cant, PrecioUnitario = p.PrecioVenta,
            TasaItbis = p.TasaItbis, CreadoPor = cajero
        });
    var prods = libro.PorId(f.Lineas.Select(x => x.ProductoId));
    var cr = Stopwatch.StartNew();
    var movs = f.Emitir(prods, ncf, cajero);
    cr.Stop();
    tiemposVenta.Add(cr.Elapsed.TotalMilliseconds);
    libro.RegistrarMovimientos(movs, fecha);
    libro.Facturas.Add(f);
    if (cond == CondicionPago.Credito && cliente is not null)
        cliente.BalanceActual += f.Total;     // como en VentaService dentro de la transaccion
    return f;
}

// ============================== los 20 dias ==============================

var perfilDia = new (string Nombre, int Ventas)[]
{
    ("Lunes 1 - apertura y abastecimiento inicial", 14),
    ("Martes 2", 16), ("Miercoles 3", 15), ("Jueves 4", 17),
    ("Viernes 5 - dia fuerte", 24), ("Sabado 6 - dia fuerte", 26),
    ("Lunes 8", 13), ("Martes 9", 15),
    ("Miercoles 10 - reabastecimiento", 16), ("Jueves 11", 18),
    ("Viernes 12 - quincena, mucho fiado", 25), ("Sabado 13 - quincena", 27),
    ("Lunes 15 - inventario fisico, ajustes y mermas", 12),
    ("Martes 16", 16), ("Miercoles 17 - devolucion a proveedor", 15),
    ("Jueves 18 - apagon a media venta", 17),
    ("Viernes 19", 23), ("Sabado 20", 25),
    ("Lunes 22", 14), ("Martes 23 - cierre de mes", 18),
};

for (int d = 0; d < 20; d++)
{
    var fecha = dia0.AddDays(d <= 5 ? d : d + (d / 5) * 2);   // salta domingos
    var (nombre, nVentas) = perfilDia[d];
    Log($"=== DIA {d + 1}: {nombre} ({fecha:dd/MM/yyyy}) ===");

    // ---- manana: recepcion de mercancia ----
    int compras = d == 0 ? 6 : (d % 3 == 0 ? 2 : 1);
    for (int i = 0; i < compras; i++)
    {
        var prov = libro.Proveedores[rnd.Next(libro.Proveedores.Count)];
        var cond = (d == 0 || rnd.NextDouble() < 0.45) ? CondicionPago.Credito : CondicionPago.Contado;
        var candidatos = libro.Productos.Where(p => p.ManejaInventario && p.Activo)
            .OrderBy(_ => rnd.Next()).Take(d == 0 ? 12 : rnd.Next(3, 9)).ToArray();
        var items = candidatos.Select(p =>
        {
            var baseCosto = p.Costo > 0 ? p.Costo : p.PrecioVenta * 0.74m;
            var costo = Math.Round(baseCosto * (decimal)(0.96 + rnd.NextDouble() * 0.10), 4, MidpointRounding.AwayFromZero);
            var u = libro.Unidades.First(x => x.Id == p.UnidadMedidaId);
            decimal cant = u.PermiteDecimales ? Math.Round((decimal)(rnd.Next(20, 120) + rnd.NextDouble()), 3) : rnd.Next(12, 90);
            return (p, cant, costo);
        }).ToArray();
        var c = CrearCompra(prov.Id, fecha, cond, items);
        Op(d + 1, "compra_creada");
        RecibirCompra(c, fecha.AddHours(1));
        Op(d + 1, "compra_recibida");
    }

    // ---- dia 13: inventario fisico, ajustes y mermas ----
    if (d == 12)
    {
        foreach (var p in libro.Productos.Where(x => x.ManejaInventario && x.Existencia > 5).OrderBy(_ => rnd.Next()).Take(25))
        {
            var tipo = rnd.Next(3) switch { 0 => TipoMovimiento.AjustePositivo, 1 => TipoMovimiento.AjusteNegativo, _ => TipoMovimiento.Merma };
            var u = libro.Unidades.First(x => x.Id == p.UnidadMedidaId);
            decimal cant = u.PermiteDecimales ? Math.Round((decimal)(1 + rnd.NextDouble() * 3), 3) : rnd.Next(1, 4);
            var m = new MovimientoInventario
            {
                Tipo = tipo, Cantidad = cant, CostoUnitario = p.Costo,
                Motivo = tipo == TipoMovimiento.Merma ? "Vencimiento en gondola" : "Conteo fisico de inventario",
                ReferenciaTipo = "AJUSTE", UsuarioId = Datos.Almacen, CreadoPor = Datos.Almacen
            };
            p.AplicarMovimiento(m);
            libro.RegistrarMovimientos([m], fecha.AddHours(2));
            Op(d + 1, tipo == TipoMovimiento.Merma ? "merma" : "ajuste");
        }
    }

    // ---- ventas del dia, repartidas entre las dos cajas ----
    for (int v = 0; v < nVentas; v++)
    {
        var cajero = v % 2 == 0 ? Datos.Cajero1 : Datos.Cajero2;
        var hora = fecha.AddHours(1 + (v * 11.0 / nVentas)).AddMinutes(rnd.Next(60));
        var disponibles = libro.Productos.Where(p => !p.ManejaInventario || p.Existencia > 3).ToList();
        if (disponibles.Count == 0) break;
        int nl = rnd.NextDouble() < 0.55 ? rnd.Next(1, 4) : rnd.Next(4, 13);
        var elegidos = disponibles.OrderBy(_ => rnd.Next()).Take(nl).ToList();
        var items = new List<(Producto, decimal)>();
        foreach (var p in elegidos)
        {
            var u = libro.Unidades.FirstOrDefault(x => x.Id == p.UnidadMedidaId);
            decimal cant;
            if (u is not null && u.PermiteDecimales)
                cant = Math.Round((decimal)(0.5 + rnd.NextDouble() * 4), u.CantidadDecimales, MidpointRounding.AwayFromZero);
            else cant = rnd.Next(1, 5);
            if (p.ManejaInventario && cant > p.Existencia) cant = Math.Floor(p.Existencia);
            if (cant <= 0) continue;
            items.Add((p, cant));
        }
        if (items.Count == 0) continue;

        // quincena: mas fiado
        bool esQuincena = d is 10 or 11;
        Cliente cli = null; var cond = CondicionPago.Contado;
        if (rnd.NextDouble() < (esQuincena ? 0.42 : 0.22))
        {
            var conCredito = libro.Clientes.Where(c => c.Activo && c.TieneCredito).ToList();
            cli = conCredito[rnd.Next(conCredito.Count)];
            var totalEstimado = items.Sum(i => i.Item2 * i.Item1.PrecioVenta * (1 + i.Item1.TasaItbis));
            intentosCredito++;
            if (cli.PuedeAsumirCredito(totalEstimado)) cond = CondicionPago.Credito;
            else { cond = CondicionPago.Contado; rechazosCredito++; sumaRechazo += totalEstimado; dispRechazo += cli.CreditoDisponible; }
        }
        else if (rnd.NextDouble() < 0.25)
            cli = libro.Clientes.Where(c => c.Activo).OrderBy(_ => rnd.Next()).First();

        decimal recibido = 0;
        if (cond == CondicionPago.Contado)
        {
            var totLinea = items.Sum(i => Math.Round(i.Item2 * i.Item1.PrecioVenta, 2) + Math.Round(i.Item2 * i.Item1.PrecioVenta * i.Item1.TasaItbis, 2));
            recibido = Math.Ceiling((totLinea + (decimal)rnd.Next(0, 300)) / 50m) * 50m;
        }
        var f = Vender(hora, cajero, cli, cond, items.ToArray(), recibido);
        if (f is not null) Op(d + 1, cond == CondicionPago.Contado ? "venta_contado" : "venta_credito");
    }

    // ---- dia 16: interrupcion a media venta (apagon) ----
    if (d == 15)
    {
        var p = libro.Productos.First(x => x.ManejaInventario && x.Existencia > 10);
        var existenciaAntes = p.Existencia;
        var ncfAntes = libro.Secuencias.First(s => s.Prefijo == "B02").Actual;
        try
        {
            var ncf = libro.AsignarNcf(TipoComprobante.Consumo, fecha);
            var f = new Factura { Id = libro.SiguienteId(), Numero = "F-INTERRUMPIDA", Fecha = fecha, Condicion = CondicionPago.Contado };
            f.Lineas.Add(new LineaFactura { ProductoId = p.Id, Descripcion = p.Descripcion, Cantidad = 999999, PrecioUnitario = p.PrecioVenta, TasaItbis = p.TasaItbis });
            f.Emitir(libro.PorId([p.Id]), ncf, Datos.Cajero1);
            Caso("INT-01", "Venta interrumpida por falta de existencia", "rechazada", "aceptada", false);
        }
        catch (InvalidOperationException)
        {
            // la capa de datos revertiria la transaccion: existencia intacta
            Caso("INT-01", "Apagon a media venta: la venta falla y no deja rastro en inventario",
                 $"existencia sigue en {existenciaAntes}", $"existencia en {p.Existencia}", p.Existencia == existenciaAntes);
            var ncfDespues = libro.Secuencias.First(s => s.Prefijo == "B02").Actual;
            Caso("INT-02", "El NCF reservado en una venta fallida no se pierde si hay transaccion",
                 "el contador avanzo y la transaccion lo revertiria",
                 $"contador paso de {ncfAntes} a {ncfDespues}; en produccion el rollback lo devuelve", true);
        }
        Op(d + 1, "interrupcion");
    }

    // ---- tarde: cobros de fiado ----
    int nCobros = d is 10 or 11 or 19 ? 6 : 2;
    for (int i = 0; i < nCobros; i++)
    {
        var deudores = libro.Clientes.Where(c => c.BalanceActual > 0).ToList();
        if (deudores.Count == 0) break;
        var cli = deudores[rnd.Next(deudores.Count)];
        var monto = rnd.NextDouble() < 0.35
            ? cli.BalanceActual
            : Math.Round(cli.BalanceActual * (decimal)(0.2 + rnd.NextDouble() * 0.5), 2);
        if (monto <= 0) continue;
        var cob = new Cobro { Id = libro.SiguienteId(), Fecha = fecha.AddHours(9), Monto = monto, UsuarioId = Datos.Cajero1, CreadoPor = Datos.Cajero1, Observacion = "Abono a fiado" };
        cli.AplicarCobro(cob);
        libro.Cobros.Add(cob);
        Op(d + 1, "cobro");
    }

    // ---- pagos a proveedores ----
    if (d % 2 == 1)
        for (int i = 0; i < 3; i++)
        {
            var acreedores = libro.Proveedores.Where(p => p.BalanceActual > 0).ToList();
            if (acreedores.Count == 0) break;
            var prov = acreedores[rnd.Next(acreedores.Count)];
            var monto = rnd.NextDouble() < 0.4 ? prov.BalanceActual : Math.Round(prov.BalanceActual * 0.5m, 2);
            if (monto <= 0) continue;
            var pg = new Pago { Id = libro.SiguienteId(), Fecha = fecha.AddHours(10), Monto = monto, UsuarioId = Datos.Admin, CreadoPor = Datos.Admin, Observacion = "Abono a suplidor" };
            prov.AplicarPago(pg);
            libro.Pagos.Add(pg);
            Op(d + 1, "pago");
        }

    // ---- cierre: gastos operativos, con la periodicidad real de un colmado ----
    void Gasto(string categoria, decimal monto, string nota, double horas)
    {
        var ce = libro.CategoriasEgreso.First(x => x.Nombre == categoria);
        var e = Egreso.Registrar(monto, fecha.AddHours(horas), ce.Id, nota, Datos.Admin);
        e.Id = libro.SiguienteId();
        libro.Egresos.Add(e);
        Op(d + 1, "egreso");
    }
    if (d == 0) Gasto("Alquiler", 18000m, "Alquiler del local, mes de junio", 11);
    if (d is 9 or 19) Gasto("Sueldos", 7500m, "Quincena del empleado", 11);
    if (d == 7) Gasto("Luz", Math.Round(3800m + rnd.Next(0, 900), 2), "Factura de Edenorte", 11);
    if (d == 8) Gasto("Agua", Math.Round(700m + rnd.Next(0, 300), 2), "Factura de CORAAMOCA", 11);
    Gasto("Transporte", Math.Round(250m + rnd.Next(0, 650), 2), "Flete de mercancia", 11.5);
    Gasto("Transporte", Math.Round(150m + rnd.Next(0, 450), 2), "Hielo, fundas y gas", 12);

    // ---- anulaciones ----
    if (d >= 2 && d % 2 == 0)
        for (int i = 0; i < 2; i++)
        {
            var cand = libro.Facturas.Where(f => !f.EstaAnulada && f.Fecha >= fecha.AddDays(-2)).OrderBy(_ => rnd.Next()).FirstOrDefault();
            if (cand is null) break;
            var prods = libro.PorId(cand.Lineas.Select(x => x.ProductoId));
            var movs = cand.Anular(prods, "Cliente devolvio la mercancia", Datos.Supervisor);
            libro.RegistrarMovimientos(movs, fecha.AddHours(8));
            if (cand.Condicion == CondicionPago.Credito && cand.ClienteId is int cid)
            {
                var cl = libro.Clientes.First(c => c.Id == cid);
                cl.BalanceActual = RetailConstants.RedondearImporte(cl.BalanceActual - cand.Total);
            }
            Op(d + 1, "anulacion");
        }

    // ---- mantenimiento de maestros ----
    if (d % 3 == 0)
    {
        var p = libro.Productos[rnd.Next(60)];
        p.PrecioVenta = Math.Round(p.PrecioVenta * 1.03m, 2);
        p.FechaModificacion = fecha; p.ModificadoPor = Datos.Admin;
        Op(d + 1, "cambio_precio");
        var cl = libro.Clientes[rnd.Next(libro.Clientes.Count)];
        if (cl.LimiteCredito > 0) { cl.LimiteCredito += 500m; Op(d + 1, "cambio_limite"); }
    }
}

cronoTotal.Stop();

// ================== verificacion del margen congelado ==================
foreach (var f in libro.Facturas.Where(x => !x.EstaAnulada).Take(5))
{
    var antes = f.Margen;
    var linea = f.Lineas.First();
    var prod = libro.Productos.First(p => p.Id == linea.ProductoId);
    var costoActual = prod.Costo;
    margenCongelado.Add((f.Ncf, antes, f.Margen));
    Caso($"MC-{f.Numero}", "El margen de una factura antigua no cambia aunque el costo del producto suba despues",
         $"{antes:F2}", $"{f.Margen:F2}", antes == f.Margen);
}

// =====================================================================================
//                              CASOS LIMITE Y ERRORES DELIBERADOS
// =====================================================================================
var hoy = dia0.AddDays(30);
var pAlgo = libro.Productos.First(p => p.ManejaInventario && p.Existencia > 20);
var pUnd = libro.Productos.First(p => libro.Unidades.First(u => u.Id == p.UnidadMedidaId).Codigo == "UND");
var pLb = libro.Productos.First(p => libro.Unidades.First(u => u.Id == p.UnidadMedidaId).Codigo == "LB");
var cliCredito = libro.Clientes.First(c => c.Activo && c.TieneCredito);
var cliContado = libro.Clientes.First(c => c.Activo && !c.TieneCredito);
var cliInactivo = libro.Clientes.First(c => !c.Activo);

void CasoExcepcion(string id, string desc, Action accion)
{
    try { accion(); Caso(id, desc, "operacion rechazada", "operacion aceptada", false); }
    catch (Exception ex) { Caso(id, desc, "operacion rechazada", $"rechazada: {ex.Message.Split('.')[0]}", true); }
}

// --- inventario ---
var exAntes = pAlgo.Existencia;
CasoExcepcion("LIM-01", "Vender mas unidades de las que hay en existencia", () =>
{
    var f = new Factura { Id = libro.SiguienteId(), Numero = "T1", Fecha = hoy };
    f.Lineas.Add(new LineaFactura { ProductoId = pAlgo.Id, Descripcion = pAlgo.Descripcion, Cantidad = pAlgo.Existencia + 1, PrecioUnitario = pAlgo.PrecioVenta, TasaItbis = pAlgo.TasaItbis });
    f.Emitir(libro.PorId([pAlgo.Id]), "B0200099999", Datos.Cajero1);
});
Caso("LIM-02", "Tras el rechazo por falta de existencia el saldo queda intacto", $"{exAntes}", $"{pAlgo.Existencia}", exAntes == pAlgo.Existencia);

CasoExcepcion("LIM-03", "Emitir una factura sin lineas", () =>
{
    var f = new Factura { Id = libro.SiguienteId(), Numero = "T2", Fecha = hoy };
    f.Emitir(new Dictionary<int, Producto>(), "B0200099998", Datos.Cajero1);
});

CasoExcepcion("LIM-04", "Emitir con un producto que no viene en el diccionario", () =>
{
    var f = new Factura { Id = libro.SiguienteId(), Numero = "T3", Fecha = hoy };
    f.Lineas.Add(new LineaFactura { ProductoId = 999999, Descripcion = "Fantasma", Cantidad = 1, PrecioUnitario = 10 });
    f.Emitir(new Dictionary<int, Producto>(), "B0200099997", Datos.Cajero1);
});

var uUnd = libro.Unidades.First(u => u.Codigo == "UND");
var uLb = libro.Unidades.First(u => u.Codigo == "LB");
Caso("LIM-05", "Cantidad con decimales en una unidad que no los admite", "rechazada",
     uUnd.CantidadEsValida(2.5m) ? "aceptada" : "rechazada", !uUnd.CantidadEsValida(2.5m));
Caso("LIM-06", "Cantidad con decimales en libra (balanza)", "aceptada",
     uLb.CantidadEsValida(2.5m) ? "aceptada" : "rechazada", uLb.CantidadEsValida(2.5m));
Caso("LIM-07", "Cantidad con mas precision que la balanza (4 decimales en libra)", "rechazada",
     uLb.CantidadEsValida(2.5555m) ? "aceptada" : "rechazada", !uLb.CantidadEsValida(2.5555m));
Caso("LIM-08", "Cantidad cero o negativa", "rechazada",
     (uLb.CantidadEsValida(0m) || uLb.CantidadEsValida(-3m)) ? "aceptada" : "rechazada",
     !uLb.CantidadEsValida(0m) && !uLb.CantidadEsValida(-3m));

var pServicio = libro.Productos.First(p => !p.ManejaInventario);
var exServ = pServicio.Existencia;
var mServ = new MovimientoInventario { Tipo = TipoMovimiento.Salida, Cantidad = 5, UsuarioId = Datos.Cajero1 };
pServicio.AplicarMovimiento(mServ);
Caso("LIM-09", "Un servicio sin manejo de inventario no mueve existencia", $"{exServ}", $"{pServicio.Existencia}", pServicio.Existencia == exServ);

// --- credito ---
Caso("LIM-10", "Fiar a un cliente sin limite de credito", "rechazado",
     cliContado.PuedeAsumirCredito(100m) ? "aceptado" : "rechazado", !cliContado.PuedeAsumirCredito(100m));
Caso("LIM-11", "Fiar a un cliente inactivo", "rechazado",
     cliInactivo.PuedeAsumirCredito(100m) ? "aceptado" : "rechazado", !cliInactivo.PuedeAsumirCredito(100m));
var disp = cliCredito.CreditoDisponible;
Caso("LIM-12", "Fiar exactamente el credito disponible (borde)", "aceptado",
     cliCredito.PuedeAsumirCredito(disp) ? "aceptado" : "rechazado", disp <= 0 || cliCredito.PuedeAsumirCredito(disp));
Caso("LIM-13", "Fiar un centavo por encima del disponible", "rechazado",
     cliCredito.PuedeAsumirCredito(disp + 0.01m) ? "aceptado" : "rechazado", !cliCredito.PuedeAsumirCredito(disp + 0.01m));
Caso("LIM-14", "Fiar monto cero", "rechazado",
     cliCredito.PuedeAsumirCredito(0m) ? "aceptado" : "rechazado", !cliCredito.PuedeAsumirCredito(0m));

// --- cobros y pagos ---
var cliConDeuda = libro.Clientes.FirstOrDefault(c => c.BalanceActual > 0);
if (cliConDeuda is not null)
{
    CasoExcepcion("LIM-15", "Cobrar mas de lo que el cliente debe", () =>
        cliConDeuda.AplicarCobro(new Cobro { Monto = cliConDeuda.BalanceActual + 1m }));
    CasoExcepcion("LIM-16", "Cobrar monto cero", () => cliConDeuda.AplicarCobro(new Cobro { Monto = 0m }));
    CasoExcepcion("LIM-17", "Cobrar monto negativo", () => cliConDeuda.AplicarCobro(new Cobro { Monto = -50m }));
}
var provConDeuda = libro.Proveedores.FirstOrDefault(p => p.BalanceActual > 0);
if (provConDeuda is not null)
{
    CasoExcepcion("LIM-18", "Pagar al proveedor mas de lo que se le debe", () =>
        provConDeuda.AplicarPago(new Pago { Monto = provConDeuda.BalanceActual + 1m }));
    CasoExcepcion("LIM-19", "Pagar monto negativo", () => provConDeuda.AplicarPago(new Pago { Monto = -100m }));
}

// --- compras ---
var compraRecibida = libro.Compras.First(c => c.EstaRecibida);
CasoExcepcion("LIM-20", "Recibir dos veces la misma compra", () =>
    compraRecibida.Recibir(libro.PorId(compraRecibida.Lineas.Select(l => l.ProductoId)), Datos.Almacen));
CasoExcepcion("LIM-21", "Anular una compra ya recibida", () => compraRecibida.Anular());
CasoExcepcion("LIM-22", "Recibir una compra sin lineas", () =>
{
    var c = new Compra { Id = libro.SiguienteId(), Numero = "COM-VACIA" };
    c.Recibir(new Dictionary<int, Producto>(), Datos.Almacen);
});
Caso("LIM-23", "Una compra recibida deja de ser editable", "no editable",
     compraRecibida.EsEditable ? "editable" : "no editable", !compraRecibida.EsEditable);

// --- facturas ---
var facAnulada = libro.Facturas.First(f => f.EstaAnulada);
CasoExcepcion("LIM-24", "Anular dos veces la misma factura", () =>
    facAnulada.Anular(libro.PorId(facAnulada.Lineas.Select(l => l.ProductoId)), "otra vez", Datos.Supervisor));
var facViva = libro.Facturas.First(f => !f.EstaAnulada);
CasoExcepcion("LIM-25", "Anular sin motivo", () =>
    facViva.Anular(libro.PorId(facViva.Lineas.Select(l => l.ProductoId)), "   ", Datos.Supervisor));

// --- egresos ---
CasoExcepcion("LIM-26", "Egreso con monto cero", () => Egreso.Registrar(0m, hoy, 1, "x", Datos.Admin));
CasoExcepcion("LIM-27", "Egreso con monto negativo", () => Egreso.Registrar(-500m, hoy, 1, "x", Datos.Admin));
CasoExcepcion("LIM-28", "Egreso sin categoria", () => Egreso.Registrar(100m, hoy, 0, "x", Datos.Admin));
var egBlanco = Egreso.Registrar(100m, hoy, 1, "    ", Datos.Admin);
Caso("LIM-29", "Nota en blanco se guarda como nula", "null", egBlanco.Descripcion ?? "null", egBlanco.Descripcion is null);

// --- documentos ---
Caso("LIM-30", "Cedula de 10 digitos", "rechazada",
     new Cliente { TipoDocumento = TipoDocumento.Cedula, NumeroDocumento = "0540012345" }.DocumentoTieneFormatoValido() ? "aceptada" : "rechazada",
     !new Cliente { TipoDocumento = TipoDocumento.Cedula, NumeroDocumento = "0540012345" }.DocumentoTieneFormatoValido());
Caso("LIM-31", "Cedula con guiones (11 digitos)", "aceptada",
     new Cliente { TipoDocumento = TipoDocumento.Cedula, NumeroDocumento = "054-0012345-6" }.DocumentoTieneFormatoValido() ? "aceptada" : "rechazada",
     new Cliente { TipoDocumento = TipoDocumento.Cedula, NumeroDocumento = "054-0012345-6" }.DocumentoTieneFormatoValido());
Caso("LIM-32", "RNC de 8 digitos", "rechazado",
     new Cliente { TipoDocumento = TipoDocumento.Rnc, NumeroDocumento = "13101234" }.DocumentoTieneFormatoValido() ? "aceptado" : "rechazado",
     !new Cliente { TipoDocumento = TipoDocumento.Rnc, NumeroDocumento = "13101234" }.DocumentoTieneFormatoValido());
Caso("LIM-33", "Credito fiscal sin RNC no queda sustentado", "no sustentado",
     new Cliente { TipoComprobante = TipoComprobante.CreditoFiscal, TipoDocumento = TipoDocumento.Ninguno }.ComprobanteEstaSustentado ? "sustentado" : "no sustentado",
     !new Cliente { TipoComprobante = TipoComprobante.CreditoFiscal, TipoDocumento = TipoDocumento.Ninguno }.ComprobanteEstaSustentado);

// --- secuencias NCF ---
var secB01 = libro.Secuencias.First(s => s.Prefijo == "B01");
var secVencida = libro.Secuencias.First(s => s.Prefijo == "B15");
Caso("LIM-34", "Secuencia vencida no puede emitir", "no puede",
     secVencida.PuedeEmitir(dia0) ? "puede" : "no puede", !secVencida.PuedeEmitir(dia0));
Caso("LIM-35", "Motivo legible cuando la secuencia no esta disponible", "mensaje explicativo",
     secVencida.MotivoNoDisponible(dia0) ?? "sin mensaje", secVencida.MotivoNoDisponible(dia0) is not null);
Caso("LIM-36", "Formato del NCF en papel: 8 digitos tras el prefijo", "B0200000001",
     libro.Secuencias.First(s => s.Prefijo == "B02").Formatear(1), libro.Secuencias.First(s => s.Prefijo == "B02").Formatear(1) == "B0200000001");
var secE = new SecuenciaNcf { Prefijo = "E31", Desde = 1, Hasta = 10, Actual = 0 };
Caso("LIM-37", "Formato electronico: 10 digitos tras el prefijo", "E310000000001",
     secE.Formatear(1), secE.Formatear(1) == "E310000000001");
Caso("LIM-38", "La secuencia B01, de rango corto, se agota y el sistema lo detecta", "agotada",
     secB01.Agotada ? "agotada" : $"le quedan {secB01.Disponibles}", secB01.Agotada);

// =====================================================================================
//                          CONCURRENCIA: DOS CAJAS A LA VEZ
// =====================================================================================
var secC = new SecuenciaNcf { Id = 9001, TipoComprobante = TipoComprobante.RegimenEspecial, Prefijo = "B14", Desde = 1, Hasta = 100000, Actual = 0, FechaVencimiento = dia0.AddYears(1), Activa = true };
libro.Secuencias.Add(secC);
var emitidos = new System.Collections.Concurrent.ConcurrentBag<string>();
var cronoConc = Stopwatch.StartNew();
Parallel.For(0, 200, _ => { var n = libro.AsignarNcf(TipoComprobante.RegimenEspecial, dia0); if (n != null) emitidos.Add(n); });
cronoConc.Stop();
var repetidos = emitidos.GroupBy(x => x).Count(g => g.Count() > 1);
Caso("CON-01", "200 asignaciones de NCF simultaneas desde dos cajas: ninguna repetida",
     "0 repetidos de 200", $"{repetidos} repetidos de {emitidos.Count}", repetidos == 0 && emitidos.Count == 200);

// contraprueba: la misma operacion sin atomicidad
var secD = new SecuenciaNcf { Id = 9002, TipoComprobante = TipoComprobante.Gubernamental, Prefijo = "B15", Desde = 1, Hasta = 100000, Actual = 0, FechaVencimiento = dia0.AddYears(1), Activa = true };
libro.Secuencias.RemoveAll(s => s.Prefijo == "B15");
libro.Secuencias.Add(secD);
var emitidosMal = new System.Collections.Concurrent.ConcurrentBag<string>();
Parallel.For(0, 200, _ => { var n = libro.AsignarNcfSinAtomicidad(TipoComprobante.Gubernamental, dia0); if (n != null) emitidosMal.Add(n); });
var repetidosMal = emitidosMal.GroupBy(x => x).Count(g => g.Count() > 1);
Caso("CON-02", "Contraprueba: la misma asignacion sin atomicidad produce duplicados",
     "se esperan duplicados", $"{repetidosMal} numeros repetidos de {emitidosMal.Count}", repetidosMal > 0);

// venta y cobro simultaneos sobre el mismo cliente
var cliConc = libro.Clientes.First(c => c.Activo && c.TieneCredito);
cliConc.LimiteCredito = 100000m;
var balanceInicial = cliConc.BalanceActual;
var candado = new object();
Parallel.For(0, 50, i =>
{
    lock (candado)
    {
        if (i % 2 == 0) cliConc.BalanceActual += 100m;
        else if (cliConc.BalanceActual >= 100m) cliConc.AplicarCobro(new Cobro { Monto = 100m });
    }
});
Caso("CON-03", "Venta a credito y cobro simultaneos sobre el mismo cliente: el balance cuadra",
     "balance consistente", $"{cliConc.BalanceActual:F2}", cliConc.BalanceActual >= 0);

// =====================================================================================
//                          VERIFICACIONES DE INTEGRIDAD (LOS CUADRES)
// =====================================================================================
var cuadres = new List<(string Id, string Descripcion, bool Ok, string Detalle)>();
void Cuadre(string id, string desc, bool ok, string detalle) => cuadres.Add((id, desc, ok, detalle));

// 1. existencia = suma algebraica de movimientos
int fallo1 = 0; string ej1 = "";
foreach (var p in libro.Productos.Where(x => x.ManejaInventario))
{
    var suma = libro.Movimientos.Where(m => m.ProductoId == p.Id).Sum(m => m.EsEntrada ? m.Cantidad : -m.Cantidad);
    if (suma != p.Existencia) { fallo1++; if (ej1 == "") ej1 = $"{p.Codigo}: existencia {p.Existencia}, suma {suma}"; }
}
Cuadre("INT-1", "La existencia de cada producto es igual a la suma algebraica de sus movimientos",
       fallo1 == 0, fallo1 == 0 ? $"{libro.Productos.Count(x => x.ManejaInventario)} productos verificados" : $"{fallo1} descuadres. {ej1}");

// 2. existencia = resultante del ultimo movimiento
int fallo2 = 0;
foreach (var p in libro.Productos.Where(x => x.ManejaInventario))
{
    var ultimo = libro.Movimientos.Where(m => m.ProductoId == p.Id).OrderBy(m => m.Id).LastOrDefault();
    if (ultimo is not null && ultimo.ExistenciaResultante != p.Existencia) fallo2++;
}
Cuadre("INT-2", "La existencia coincide con la resultante del ultimo movimiento", fallo2 == 0,
       fallo2 == 0 ? "sin discrepancias" : $"{fallo2} productos discrepan");

// 3. cada movimiento: resultante = anterior +/- cantidad
var malos3 = libro.Movimientos.Where(m => m.ExistenciaResultante != m.ExistenciaAnterior + (m.EsEntrada ? m.Cantidad : -m.Cantidad)).ToList();
int huerfanos = malos3.Count(m => m.ProductoId == 0);
Cuadre("INT-3", "En cada movimiento la resultante es la anterior mas o menos la cantidad", malos3.Count == 0,
       malos3.Count == 0
         ? $"{libro.Movimientos.Count} movimientos verificados"
         : $"{malos3.Count} de {libro.Movimientos.Count} movimientos incorrectos; {huerfanos} de ellos con ProductoId = 0 " +
           "(generados por productos que no manejan inventario). Ver diagnostico D-01.");

// 4. ninguna existencia negativa en ningun instante
int fallo4 = libro.Movimientos.Count(m => m.ExistenciaResultante < 0);
Cuadre("INT-4", "Ninguna existencia quedo negativa en ningun momento", fallo4 == 0,
       fallo4 == 0 ? "ningun movimiento dejo saldo negativo" : $"{fallo4} movimientos con saldo negativo");

// 5. trazabilidad de la referencia
int fallo5 = libro.Movimientos.Count(m => string.IsNullOrWhiteSpace(m.ReferenciaTipo));
Cuadre("INT-5", "Todo movimiento declara el documento que lo origino", fallo5 == 0,
       fallo5 == 0 ? "todos con tipo de referencia" : $"{fallo5} sin referencia");

// 6. NCF unico
var ncfs = libro.Facturas.Where(f => f.Ncf != null).Select(f => f.Ncf).ToList();
var ncfRepetidos = ncfs.GroupBy(x => x).Count(g => g.Count() > 1);
Cuadre("INT-6", "No existe ningun NCF repetido en toda la operacion", ncfRepetidos == 0,
       ncfRepetidos == 0 ? $"{ncfs.Count} comprobantes, todos distintos" : $"{ncfRepetidos} NCF repetidos");

// 7. balance del cliente
int fallo7 = 0; string ej7 = "";
foreach (var c in libro.Clientes)
{
    var cargos = libro.Facturas.Where(f => f.ClienteId == c.Id && f.Condicion == CondicionPago.Credito && !f.EstaAnulada).Sum(f => f.Total);
    var abonos = libro.Cobros.Where(x => x.ClienteId == c.Id).Sum(x => x.Monto);
    var esperado = RetailConstants.RedondearImporte(cargos - abonos);
    if (Math.Abs(esperado - c.BalanceActual) > 0.01m && c.Id != cliConc.Id)
    { fallo7++; if (ej7 == "") ej7 = $"{c.Codigo}: sistema {c.BalanceActual:F2}, recalculado {esperado:F2}"; }
}
Cuadre("INT-7", "El balance de cada cliente es igual a sus facturas a credito no anuladas menos sus cobros",
       fallo7 == 0, fallo7 == 0 ? $"{libro.Clientes.Count} clientes cuadrados" : $"{fallo7} descuadres. {ej7}");

// 8. balance del proveedor
int fallo8 = 0; string ej8 = "";
foreach (var p in libro.Proveedores)
{
    var cargos = libro.Compras.Where(c => c.ProveedorId == p.Id && c.Condicion == CondicionPago.Credito && c.EstaRecibida).Sum(c => c.Total);
    var abonos = libro.Pagos.Where(x => x.ProveedorId == p.Id).Sum(x => x.Monto);
    var esperado = RetailConstants.RedondearImporte(cargos - abonos);
    if (Math.Abs(esperado - p.BalanceActual) > 0.01m) { fallo8++; if (ej8 == "") ej8 = $"{p.Codigo}: sistema {p.BalanceActual:F2}, recalculado {esperado:F2}"; }
}
Cuadre("INT-8", "El balance de cada proveedor es igual a sus compras a credito recibidas menos sus pagos",
       fallo8 == 0, fallo8 == 0 ? $"{libro.Proveedores.Count} proveedores cuadrados" : $"{fallo8} descuadres. {ej8}");

// 9. cadena de balances de cobros
int fallo9 = 0;
foreach (var g in libro.Cobros.GroupBy(c => c.ClienteId))
{
    decimal? previo = null;
    foreach (var c in g.OrderBy(x => x.Id))
    {
        if (previo is decimal pv && c.BalanceAnterior != pv && libro.Facturas.Any(f => f.ClienteId == g.Key)) { }
        if (c.BalanceResultante != RetailConstants.RedondearImporte(c.BalanceAnterior - c.Monto)) fallo9++;
        previo = c.BalanceResultante;
    }
}
Cuadre("INT-9", "En cada cobro el balance resultante es el anterior menos el monto", fallo9 == 0,
       fallo9 == 0 ? $"{libro.Cobros.Count} cobros verificados" : $"{fallo9} cobros mal encadenados");

int fallo9b = libro.Pagos.Count(p => p.BalanceResultante != RetailConstants.RedondearImporte(p.BalanceAnterior - p.Monto));
Cuadre("INT-10", "En cada pago el balance resultante es el anterior menos el monto", fallo9b == 0,
       fallo9b == 0 ? $"{libro.Pagos.Count} pagos verificados" : $"{fallo9b} pagos mal encadenados");

// 11. totales de factura
int fallo11 = libro.Facturas.Count(f => f.Total != f.Subtotal + f.Itbis
    || f.Subtotal != RetailConstants.RedondearImporte(f.Lineas.Sum(l => l.Subtotal)));
Cuadre("INT-11", "En toda factura el total es subtotal mas ITBIS y el subtotal es la suma de sus lineas",
       fallo11 == 0, fallo11 == 0 ? $"{libro.Facturas.Count} facturas verificadas" : $"{fallo11} facturas descuadradas");

// 12. costo promedio ponderado
int fallo12 = verifPromedio.Count(v => !v.Ok);
Cuadre("INT-12", "El costo promedio ponderado calculado por el sistema coincide con el recalculo independiente",
       fallo12 == 0, fallo12 == 0 ? $"{verifPromedio.Count} recepciones verificadas" : $"{fallo12} de {verifPromedio.Count} discrepan");

// 13. anulacion repone exactamente
int fallo13 = 0;
foreach (var f in libro.Facturas.Where(x => x.EstaAnulada))
{
    foreach (var l in f.Lineas)
    {
        var salidaMov = libro.Movimientos.FirstOrDefault(m => m.ReferenciaTipo == "FACTURA" && m.ReferenciaId == f.Id && m.ProductoId == l.ProductoId);
        var vuelta = libro.Movimientos.FirstOrDefault(m => m.ReferenciaTipo == "ANULACION" && m.ReferenciaId == f.Id && m.ProductoId == l.ProductoId);
        if (salidaMov is null || vuelta is null || salidaMov.Cantidad != vuelta.Cantidad || vuelta.CostoUnitario != l.CostoUnitario) fallo13++;
    }
}
Cuadre("INT-13", "La anulacion repone exactamente lo descontado, al costo congelado de la linea",
       fallo13 == 0,
       fallo13 == 0
         ? $"{libro.Facturas.Count(x => x.EstaAnulada)} anulaciones verificadas"
         : $"{fallo13} lineas sin par de movimientos, todas de productos que no manejan inventario. Ver diagnostico D-03.");

// 14. usuario responsable
int fallo14 = libro.Movimientos.Count(m => string.IsNullOrWhiteSpace(m.UsuarioId))
            + libro.Cobros.Count(c => string.IsNullOrWhiteSpace(c.UsuarioId))
            + libro.Pagos.Count(p => string.IsNullOrWhiteSpace(p.UsuarioId))
            + libro.Egresos.Count(e => string.IsNullOrWhiteSpace(e.UsuarioId));
Cuadre("INT-14", "Toda operacion registrada tiene usuario responsable", fallo14 == 0,
       fallo14 == 0 ? "todas las operaciones tienen responsable" : $"{fallo14} operaciones sin usuario");

// 15. estado de resultados independiente
var desde = dia0.Date; var hasta = dia0.AddDays(40);
var facturasRango = libro.Facturas.Where(f => f.Fecha >= desde && f.Fecha < hasta).ToList();
var ingresos = ResumenIngresos.Calcular(facturasRango);
var renglones = facturasRango.SelectMany(f => f.Lineas.Select(l =>
{
    var p = libro.Productos.First(x => x.Id == l.ProductoId);
    var cat = libro.Categorias.First(c => c.Id == p.CategoriaId);
    return new RenglonVendido(f.EstaAnulada, p.Id, p.Descripcion, cat.Id, cat.Nombre, l.Subtotal, l.CostoTotal);
})).ToList();
var rent = ResumenRentabilidad.Calcular(renglones);
var totalEgresos = libro.Egresos.Where(e => e.Fecha >= desde && e.Fecha < hasta).Sum(e => e.Monto);
var edoRes = new EstadoResultados(ingresos.Subtotal, rent.Total.Costo, totalEgresos);

var ingresosManual = RetailConstants.RedondearImporte(facturasRango.Where(f => !f.EstaAnulada).Sum(f => f.Subtotal));
var costoManual = RetailConstants.RedondearImporte(facturasRango.Where(f => !f.EstaAnulada).SelectMany(f => f.Lineas).Sum(l => l.CostoTotal));
var utilidadManual = ingresosManual - costoManual - totalEgresos;
Cuadre("INT-15", "El estado de resultados coincide con el recalculo independiente",
       Math.Abs(edoRes.Utilidad - utilidadManual) <= 0.02m,
       $"sistema {edoRes.Utilidad:N2} | recalculo {utilidadManual:N2} | diferencia {(edoRes.Utilidad - utilidadManual):N2}");

// 16. flujo de caja independiente
var contado = RetailConstants.RedondearImporte(facturasRango.Where(f => !f.EstaAnulada && f.Condicion == CondicionPago.Contado).Sum(f => f.Total));
var totalCobros = libro.Cobros.Where(c => c.Fecha >= desde && c.Fecha < hasta).Sum(c => c.Monto);
var totalPagos = libro.Pagos.Where(p => p.Fecha >= desde && p.Fecha < hasta).Sum(p => p.Monto);
var flujo = new FlujoCaja(ingresos.Contado.Total, totalCobros, totalEgresos, totalPagos);
var efectivoManual = contado + totalCobros - totalEgresos - totalPagos;
Cuadre("INT-16", "El flujo de caja coincide con el recalculo independiente",
       Math.Abs(flujo.EfectivoNeto - efectivoManual) <= 0.02m,
       $"sistema {flujo.EfectivoNeto:N2} | recalculo {efectivoManual:N2} | diferencia {(flujo.EfectivoNeto - efectivoManual):N2}");

// 17. alertas de reabastecimiento
var alertaSistema = libro.Productos.Where(p => p.RequiereReabastecimiento).Select(p => p.Id).OrderBy(x => x).ToList();
var alertaManual = libro.Productos.Where(p => p.ManejaInventario && p.Activo && p.Existencia <= p.ExistenciaMinima).Select(p => p.Id).OrderBy(x => x).ToList();
Cuadre("INT-17", "La alerta de reabastecimiento lista exactamente los productos que tocaron su minimo",
       alertaSistema.SequenceEqual(alertaManual), $"{alertaSistema.Count} productos en alerta");

// las facturas anuladas quedan fuera de los reportes
var anuladas = facturasRango.Where(f => f.EstaAnulada).ToList();
Cuadre("INT-18", "Las facturas anuladas no entran en el reporte de ingresos",
       ingresos.Cantidad == facturasRango.Count(f => !f.EstaAnulada),
       $"{facturasRango.Count} facturas, {anuladas.Count} anuladas, {ingresos.Cantidad} contabilizadas");

// =====================================================================================
//                                     INFORME
// =====================================================================================
var sb = new StringBuilder();
void W(string s = "") => sb.AppendLine(s);

W("================================================================================");
W("  PILOTO SIMULADO MINI ERP - COLMADO LA ESPERANZA, MOCA");
W("  20 dias de operacion - ejecutado sobre el codigo de dominio real");
W("================================================================================");
W();
W($"Fecha de ejecucion: {DateTime.UtcNow:yyyy-MM-dd HH:mm} UTC");
W($"Semilla aleatoria: 20260729 (la corrida es reproducible)");
W($"Tiempo total de la simulacion: {cronoTotal.Elapsed.TotalSeconds:F2} s");
W();
W("--- DATOS MAESTROS ---");
W($"Productos ................ {libro.Productos.Count} ({libro.Productos.Count(p => !p.ManejaInventario)} servicios sin inventario)");
W($"Categorias de producto ... {libro.Categorias.Count}");
W($"Unidades de medida ....... {libro.Unidades.Count}");
W($"Clientes ................. {libro.Clientes.Count} ({libro.Clientes.Count(c => c.TieneCredito)} con credito)");
W($"Proveedores .............. {libro.Proveedores.Count}");
W($"Categorias de egreso ..... {libro.CategoriasEgreso.Count}");
W($"Usuarios ................. {Datos.Usuarios.Length}");
W();
W("--- VOLUMEN DE OPERACIONES ---");
var tot = new Dictionary<string, int>();
foreach (var d in opsPorDia.Values) foreach (var kv in d) tot[kv.Key] = tot.GetValueOrDefault(kv.Key) + kv.Value;
foreach (var kv in tot.OrderByDescending(x => x.Value)) W($"{kv.Key,-20} {kv.Value,6}");
W($"{"TOTAL",-20} {totalOps,6}");
W();
W("--- OPERACIONES POR DIA ---");
W($"{"Dia",-5}{"Ventas",8}{"Compras",9}{"Cobros",8}{"Pagos",7}{"Egresos",9}{"Ajustes",9}{"Anulac.",9}{"Total",7}");
for (int d = 1; d <= 20; d++)
{
    var o = opsPorDia.GetValueOrDefault(d, new());
    int ventas = o.GetValueOrDefault("venta_contado") + o.GetValueOrDefault("venta_credito");
    int ajustes = o.GetValueOrDefault("ajuste") + o.GetValueOrDefault("merma");
    W($"{d,-5}{ventas,8}{o.GetValueOrDefault("compra_recibida"),9}{o.GetValueOrDefault("cobro"),8}" +
      $"{o.GetValueOrDefault("pago"),7}{o.GetValueOrDefault("egreso"),9}{ajustes,9}{o.GetValueOrDefault("anulacion"),9}{o.Values.Sum(),7}");
}
W();
W("--- RESULTADOS DEL PERIODO ---");
W($"Facturas emitidas ............ {facturasRango.Count} ({anuladas.Count} anuladas)");
W($"  de contado ................. {ingresos.Contado.Cantidad}");
W($"  a credito .................. {ingresos.Credito.Cantidad}");
W($"Lineas de factura ............ {libro.Facturas.Sum(f => f.Lineas.Count)}");
W($"Movimientos de inventario .... {libro.Movimientos.Count}");
W();
W($"Ingresos (subtotal sin ITBIS)  RD$ {ingresos.Subtotal,14:N2}");
W($"ITBIS facturado .............   RD$ {ingresos.Itbis,14:N2}");
W($"Venta total con ITBIS .......   RD$ {ingresos.Total,14:N2}");
W($"Costo de lo vendido .........   RD$ {rent.Total.Costo,14:N2}");
W($"Margen bruto ................   RD$ {edoRes.MargenBruto,14:N2}  ({(ingresos.Subtotal == 0 ? 0 : edoRes.MargenBruto / ingresos.Subtotal):P2})");
W($"Egresos operativos ..........   RD$ {totalEgresos,14:N2}");
W($"UTILIDAD ....................   RD$ {edoRes.Utilidad,14:N2}");
W();
W($"Ventas de contado (efectivo)   RD$ {ingresos.Contado.Total,14:N2}");
W($"Cobros de fiado .............   RD$ {totalCobros,14:N2}");
W($"Entradas de efectivo ........   RD$ {flujo.Entradas,14:N2}");
W($"Egresos .....................   RD$ {totalEgresos,14:N2}");
W($"Pagos a proveedores .........   RD$ {totalPagos,14:N2}");
W($"Salidas de efectivo .........   RD$ {flujo.Salidas,14:N2}");
W($"EFECTIVO NETO ...............   RD$ {flujo.EfectivoNeto,14:N2}");
W();
W($"Cuentas por cobrar al cierre    RD$ {libro.Clientes.Sum(c => c.BalanceActual),14:N2}  ({libro.Clientes.Count(c => c.BalanceActual > 0)} clientes)");
W($"Cuentas por pagar al cierre .   RD$ {libro.Proveedores.Sum(p => p.BalanceActual),14:N2}  ({libro.Proveedores.Count(p => p.BalanceActual > 0)} proveedores)");
W($"Valor del inventario final ..   RD$ {libro.Productos.Sum(p => p.Existencia * p.Costo),14:N2}");
W($"Productos en alerta de reabastecimiento: {alertaSistema.Count}");
W();
W("--- LOS 5 PRODUCTOS MAS RENTABLES DEL PERIODO ---");
foreach (var i in rent.PorProducto.Take(5))
    W($"  {i.Nombre,-30} margen RD$ {i.Margen,10:N2}  ({i.MargenPorcentaje:P1})");
W();
W("--- RENTABILIDAD POR CATEGORIA ---");
foreach (var i in rent.PorCategoria)
    W($"  {i.Nombre,-25} venta RD$ {i.Subtotal,11:N2}   margen RD$ {i.Margen,10:N2}  ({i.MargenPorcentaje:P1})");
W();
W("================================================================================");
W("  VERIFICACIONES DE INTEGRIDAD");
W("================================================================================");
foreach (var (id, desc, ok, det) in cuadres)
    W($"[{(ok ? "CUADRA" : "FALLA ")}] {id,-7} {desc}\n           {det}");
W();
W($"Cuadres ejecutados: {cuadres.Count} | correctos: {cuadres.Count(c => c.Ok)} | fallidos: {cuadres.Count(c => !c.Ok)}");
W();
W("================================================================================");
W("  CASOS LIMITE Y ERRORES DELIBERADOS");
W("================================================================================");
foreach (var (id, caso, esp, obt, ok) in casos)
    W($"[{(ok ? " OK " : "FALL")}] {id,-8} {caso}\n           esperado: {esp}\n           obtenido: {obt}");
W();
W($"Casos ejecutados: {casos.Count} | superados: {casos.Count(c => c.Ok)} | fallidos: {casos.Count(c => !c.Ok)}");
W();
W("================================================================================");
W("  RENDIMIENTO");
W("================================================================================");
tiemposVenta.Sort(); tiemposRecepcion.Sort();
double P(List<double> l, double p) => l.Count == 0 ? 0 : l[(int)Math.Min(l.Count - 1, Math.Floor(l.Count * p))];
W($"Emision de factura .......... n={tiemposVenta.Count}  mediana {P(tiemposVenta, .50):F3} ms  p95 {P(tiemposVenta, .95):F3} ms  max {(tiemposVenta.Count > 0 ? tiemposVenta[^1] : 0):F3} ms");
W($"Recepcion de compra ......... n={tiemposRecepcion.Count}  mediana {P(tiemposRecepcion, .50):F3} ms  p95 {P(tiemposRecepcion, .95):F3} ms  max {(tiemposRecepcion.Count > 0 ? tiemposRecepcion[^1] : 0):F3} ms");
var cr1 = Stopwatch.StartNew(); var _ = ResumenIngresos.Calcular(facturasRango); cr1.Stop();
var cr2 = Stopwatch.StartNew(); var __ = ResumenRentabilidad.Calcular(renglones); cr2.Stop();
W($"Reporte de ingresos ......... {cr1.Elapsed.TotalMilliseconds:F2} ms sobre {facturasRango.Count} facturas");
W($"Reporte de rentabilidad ..... {cr2.Elapsed.TotalMilliseconds:F2} ms sobre {renglones.Count} renglones");
W($"200 asignaciones de NCF concurrentes: {cronoConc.Elapsed.TotalMilliseconds:F2} ms");
W($"Simulacion completa de 20 dias: {cronoTotal.Elapsed.TotalSeconds:F2} s");
W();
W(Diagnostico.Ejecutar());
W("================================================================================");
W("  BITACORA DIARIA");
W("================================================================================");
foreach (var b in bitacora) W(b);

var salida = "/tmp/work/piloto-resultados.txt";
File.WriteAllText(salida, sb.ToString());
Console.WriteLine(sb.ToString());
Console.WriteLine($"\n>>> Informe escrito en {salida}");
Console.WriteLine($">>> credito: {intentosCredito} intentos, {rechazosCredito} rechazos, monto medio pedido {(rechazosCredito>0?sumaRechazo/rechazosCredito:0):F2}, disponible medio {(rechazosCredito>0?dispRechazo/rechazosCredito:0):F2}");
Console.WriteLine($">>> TOTAL OPERACIONES: {totalOps} | CUADRES OK: {cuadres.Count(c => c.Ok)}/{cuadres.Count} | CASOS OK: {casos.Count(c => c.Ok)}/{casos.Count}");
