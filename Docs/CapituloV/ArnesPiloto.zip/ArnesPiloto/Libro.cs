using MiniERP.Domain.Clientes;
using MiniERP.Domain.Compras;
using MiniERP.Domain.Finanzas;
using MiniERP.Domain.Inventario;
using MiniERP.Domain.Shared;
using MiniERP.Domain.Ventas;

namespace Piloto;

/// <summary>
/// Almacen en memoria que hace el papel de la base de datos durante el piloto.
/// No reimplementa ninguna regla de negocio: solo guarda lo que el dominio produce.
/// </summary>
public class Libro
{
    private int _sig = 0;
    private readonly object _candadoNcf = new();

    public int SiguienteId() => System.Threading.Interlocked.Increment(ref _sig);

    public List<Categoria> Categorias { get; } = [];
    public List<UnidadMedida> Unidades { get; } = [];
    public List<Producto> Productos { get; } = [];
    public List<Cliente> Clientes { get; } = [];
    public List<Proveedor> Proveedores { get; } = [];
    public List<Factura> Facturas { get; } = [];
    public List<Compra> Compras { get; } = [];
    public List<Cobro> Cobros { get; } = [];
    public List<Pago> Pagos { get; } = [];
    public List<Egreso> Egresos { get; } = [];
    public List<CategoriaEgreso> CategoriasEgreso { get; } = [];
    public List<MovimientoInventario> Movimientos { get; } = [];
    public List<SecuenciaNcf> Secuencias { get; } = [];

    public Dictionary<int, Producto> PorId(IEnumerable<int> ids) =>
        Productos.Where(p => ids.Contains(p.Id)).ToDictionary(p => p.Id);

    /// <summary>
    /// Reproduce el contrato de ISecuenciaNcfRepositorio.AsignarSiguienteAsync:
    /// incremento y lectura en una sola operacion indivisible, como hace el
    /// UPDATE ... OUTPUT INSERTED de la implementacion real sobre SQL Server.
    /// </summary>
    public string AsignarNcf(TipoComprobante tipo, DateTime hoy)
    {
        lock (_candadoNcf)
        {
            var s = Secuencias.FirstOrDefault(x => x.TipoComprobante == tipo && x.PuedeEmitir(hoy));
            if (s is null) return null;
            s.Actual += 1;
            return s.Formatear(s.Actual);
        }
    }

    /// <summary>Version sin atomicidad, solo para demostrar por que la real la necesita.</summary>
    public string AsignarNcfSinAtomicidad(TipoComprobante tipo, DateTime hoy)
    {
        var s = Secuencias.FirstOrDefault(x => x.TipoComprobante == tipo && x.PuedeEmitir(hoy));
        if (s is null) return null;
        var leido = s.Actual;               // lectura
        System.Threading.Thread.SpinWait(60); // ventana entre lectura y escritura
        s.Actual = leido + 1;               // escritura
        return s.Formatear(leido + 1);
    }

    public void RegistrarMovimientos(IEnumerable<MovimientoInventario> movs, DateTime fecha)
    {
        foreach (var m in movs)
        {
            m.Id = SiguienteId();
            m.Fecha = fecha;
            Movimientos.Add(m);
        }
    }
}
