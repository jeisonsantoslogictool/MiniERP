using MiniERP.Domain.Clientes;
using MiniERP.Domain.Compras;
using MiniERP.Domain.Finanzas;
using MiniERP.Domain.Inventario;
using MiniERP.Domain.Ventas;

namespace Piloto;

/// <summary>Datos maestros del comercio ficticio "Colmado La Esperanza", Moca.</summary>
public static class Datos
{
    public const string Admin = "admin@laesperanza.do";
    public const string Cajero1 = "yulissa@laesperanza.do";
    public const string Cajero2 = "manuel@laesperanza.do";
    public const string Almacen = "ramon@laesperanza.do";
    public const string Supervisor = "carmen@laesperanza.do";
    public static readonly string[] Usuarios = [Admin, Cajero1, Cajero2, Almacen, Supervisor];

    public static void Sembrar(Libro l, DateTime dia0)
    {
        // --- unidades de medida (las 7 que siembra UnidadMedidaConfiguration) ---
        foreach (var (cod, nom, dec, n) in new (string, string, bool, int)[]
        {
            ("UND","Unidad",false,0), ("LB","Libra",true,3), ("KG","Kilogramo",true,3),
            ("GAL","Galon",true,2), ("LT","Litro",true,2), ("CAJ","Caja",false,0), ("PAQ","Paquete",false,0)
        })
            l.Unidades.Add(new UnidadMedida { Id = l.SiguienteId(), Codigo = cod, Nombre = nom, PermiteDecimales = dec, CantidadDecimales = n });

        // --- categorias de producto (las 10 sembradas por DatabaseInitializer) ---
        foreach (var n in new[] { "Viveres", "Bebidas", "Lacteos", "Carnes y Embutidos", "Panaderia",
                                  "Enlatados", "Limpieza", "Higiene Personal", "Snacks y Golosinas", "Congelados" })
            l.Categorias.Add(new Categoria { Id = l.SiguienteId(), Nombre = n, Activo = true });

        // --- categorias de egreso (las 5 sembradas) ---
        foreach (var n in new[] { "Alquiler", "Luz", "Agua", "Sueldos", "Transporte" })
            l.CategoriasEgreso.Add(new CategoriaEgreso { Id = l.SiguienteId(), Nombre = n, Activo = true });

        // --- secuencias NCF: B02 amplia, B01 corta a proposito para forzar agotamiento ---
        l.Secuencias.Add(new SecuenciaNcf { Id = l.SiguienteId(), TipoComprobante = TipoComprobante.Consumo, Prefijo = "B02", Desde = 1, Hasta = 5000, Actual = 0, FechaVencimiento = dia0.AddYears(1), Activa = true });
        l.Secuencias.Add(new SecuenciaNcf { Id = l.SiguienteId(), TipoComprobante = TipoComprobante.CreditoFiscal, Prefijo = "B01", Desde = 1, Hasta = 6, Actual = 0, FechaVencimiento = dia0.AddYears(1), Activa = true });
        l.Secuencias.Add(new SecuenciaNcf { Id = l.SiguienteId(), TipoComprobante = TipoComprobante.Gubernamental, Prefijo = "B15", Desde = 1, Hasta = 100, Actual = 0, FechaVencimiento = dia0.AddDays(-1), Activa = true }); // vencida a proposito

        // --- catalogo: 60 productos reales de colmado dominicano ---
        // (descripcion, categoria, unidad, costo, precio, minimo, exento)
        var cat = (string n) => l.Categorias.First(c => c.Nombre == n).Id;
        var und = (string c) => l.Unidades.First(u => u.Codigo == c).Id;
        var cat60 = new (string, string, string, decimal, decimal, decimal, bool)[]
        {
            ("Arroz selecto","Viveres","LB",26.50m,35.00m,50,true),
            ("Habichuela roja","Viveres","LB",38.00m,52.00m,30,true),
            ("Habichuela negra","Viveres","LB",36.00m,49.00m,25,true),
            ("Azucar crema","Viveres","LB",22.00m,30.00m,40,true),
            ("Sal fina","Viveres","LB",9.00m,14.00m,20,true),
            ("Aceite de soya 1L","Viveres","UND",118.00m,155.00m,12,false),
            ("Aceite de maiz 1L","Viveres","UND",145.00m,189.00m,8,false),
            ("Espagueti 1lb","Viveres","PAQ",31.00m,42.00m,20,false),
            ("Avena en hojuelas","Viveres","LB",44.00m,58.00m,10,false),
            ("Harina de trigo","Viveres","LB",21.00m,29.00m,15,true),
            ("Cafe molido 8oz","Viveres","UND",145.00m,190.00m,10,false),
            ("Chocolate de bola","Viveres","UND",38.00m,52.00m,12,false),
            ("Cacao en polvo","Viveres","LB",96.00m,128.00m,6,false),
            ("Maiz para moro","Viveres","LB",28.00m,38.00m,10,true),
            ("Auyama","Viveres","LB",18.00m,26.00m,15,true),
            ("Coca Cola 2L","Bebidas","UND",95.00m,125.00m,24,false),
            ("Coca Cola 600ml","Bebidas","UND",48.00m,65.00m,36,false),
            ("Country Club uva 2L","Bebidas","UND",78.00m,105.00m,18,false),
            ("Agua Alaska 1 gal","Bebidas","GAL",42.00m,60.00m,20,false),
            ("Jugo de naranja 1L","Bebidas","LT",68.00m,92.00m,12,false),
            ("Malta Morena","Bebidas","UND",52.00m,70.00m,24,false),
            ("Cerveza Presidente","Bebidas","UND",95.00m,130.00m,48,false),
            ("Ron Brugal 375ml","Bebidas","UND",285.00m,375.00m,6,false),
            ("Refresco Red Rock","Bebidas","UND",38.00m,52.00m,24,false),
            ("Leche entera 1L","Lacteos","LT",78.00m,102.00m,18,false),
            ("Leche en polvo 400g","Lacteos","UND",215.00m,278.00m,8,false),
            ("Queso de freir","Lacteos","LB",165.00m,215.00m,10,false),
            ("Queso geo","Lacteos","LB",148.00m,195.00m,8,false),
            ("Yogurt de fresa","Lacteos","UND",42.00m,58.00m,12,false),
            ("Mantequilla 1lb","Lacteos","LB",128.00m,168.00m,6,false),
            ("Pollo entero","Carnes y Embutidos","LB",52.00m,72.00m,40,true),
            ("Muslo de pollo","Carnes y Embutidos","LB",48.00m,66.00m,30,true),
            ("Carne de res molida","Carnes y Embutidos","LB",145.00m,192.00m,20,true),
            ("Chuleta de cerdo","Carnes y Embutidos","LB",118.00m,158.00m,15,true),
            ("Salami Induveca","Carnes y Embutidos","LB",132.00m,175.00m,10,false),
            ("Jamon de pierna","Carnes y Embutidos","LB",178.00m,232.00m,6,false),
            ("Salchichon","Carnes y Embutidos","UND",68.00m,92.00m,12,false),
            ("Pan de agua","Panaderia","UND",8.00m,12.00m,50,true),
            ("Pan de sandwich","Panaderia","PAQ",78.00m,105.00m,10,false),
            ("Galleta de soda","Panaderia","PAQ",42.00m,58.00m,18,false),
            ("Sardina en lata","Enlatados","UND",52.00m,72.00m,24,false),
            ("Atun en lata","Enlatados","UND",68.00m,92.00m,18,false),
            ("Salsa de tomate","Enlatados","UND",38.00m,52.00m,20,false),
            ("Maiz dulce en lata","Enlatados","UND",45.00m,62.00m,12,false),
            ("Leche evaporada","Enlatados","UND",58.00m,78.00m,18,false),
            ("Detergente 1kg","Limpieza","KG",115.00m,152.00m,12,false),
            ("Jabon de cuaba","Limpieza","UND",22.00m,32.00m,24,false),
            ("Cloro 1 gal","Limpieza","GAL",78.00m,105.00m,10,false),
            ("Suavizante 1L","Limpieza","LT",92.00m,125.00m,8,false),
            ("Papel higienico x4","Limpieza","PAQ",88.00m,118.00m,15,false),
            ("Fabuloso 1L","Limpieza","LT",85.00m,115.00m,10,false),
            ("Jabon de bano","Higiene Personal","UND",42.00m,58.00m,20,false),
            ("Pasta dental","Higiene Personal","UND",78.00m,105.00m,12,false),
            ("Desodorante","Higiene Personal","UND",125.00m,168.00m,8,false),
            ("Shampoo 400ml","Higiene Personal","UND",148.00m,195.00m,6,false),
            ("Papitas fritas","Snacks y Golosinas","UND",32.00m,45.00m,30,false),
            ("Chicle x10","Snacks y Golosinas","PAQ",28.00m,40.00m,20,false),
            ("Chocolatina","Snacks y Golosinas","UND",25.00m,35.00m,36,false),
            ("Helado 1/2 gal","Congelados","GAL",245.00m,320.00m,4,false),
            ("Vegetales mixtos","Congelados","LB",72.00m,98.00m,8,false),
        };
        int nc = 1;
        foreach (var (desc, c, u, costo, precio, min, exento) in cat60)
        {
            l.Productos.Add(new Producto
            {
                Id = l.SiguienteId(),
                Codigo = $"P{nc:000}",
                CodigoBarras = nc % 4 == 0 ? null : $"75012340{nc:0000}",
                Descripcion = desc,
                CategoriaId = cat(c),
                UnidadMedidaId = und(u),
                Costo = 0m,                    // el costo real lo fija la primera compra
                PrecioVenta = precio,
                TasaItbis = exento ? 0m : Producto.TasaItbisGeneral,
                Existencia = 0m,
                ExistenciaMinima = min,
                ManejaInventario = true,
                Activo = true,
                CreadoPor = Admin
            });
            nc++;
        }
        // 3 servicios que no manejan inventario
        foreach (var s in new[] { "Recarga telefonica", "Fotocopia", "Envio de paquete" })
            l.Productos.Add(new Producto
            {
                Id = l.SiguienteId(), Codigo = $"S{nc++:000}", Descripcion = s,
                CategoriaId = cat("Viveres"), UnidadMedidaId = und("UND"),
                Costo = 0m, PrecioVenta = 50m, TasaItbis = Producto.TasaItbisGeneral,
                ManejaInventario = false, Activo = true, CreadoPor = Admin
            });

        // --- proveedores ---
        var provs = new (string, TipoDocumento, string, int)[]
        {
            ("Distribuidora Corripio", TipoDocumento.Rnc, "101010101", 30),
            ("Mercasid", TipoDocumento.Rnc, "101020304", 30),
            ("Induveca", TipoDocumento.Rnc, "130123456", 15),
            ("Rica Dominicana", TipoDocumento.Rnc, "101567890", 15),
            ("Cerveceria Nacional", TipoDocumento.Rnc, "101112131", 21),
            ("Molinos del Ozama", TipoDocumento.Rnc, "101415161", 30),
            ("Pasteurizadora Rica", TipoDocumento.Rnc, "101718192", 15),
            ("Colgate Dominicana", TipoDocumento.Rnc, "102021222", 45),
            ("Don Rafael (viveres)", TipoDocumento.Cedula, "05400123456", 7),
            ("Panaderia La Union", TipoDocumento.Cedula, "05400234567", 7),
            ("Frigorifico del Norte", TipoDocumento.Rnc, "102324252", 21),
            ("Vendedor ambulante", TipoDocumento.Ninguno, null, 0),
        };
        int np = 1;
        foreach (var (nom, td, doc, dias) in provs)
            l.Proveedores.Add(new Proveedor
            {
                Id = l.SiguienteId(), Codigo = $"PRV-{np++:000}", Nombre = nom,
                TipoDocumento = td, NumeroDocumento = doc, DiasCredito = dias,
                BalanceActual = 0m, Activo = true, CreadoPor = Admin
            });

        // --- clientes: 40, con y sin credito ---
        var nombres = new[]
        {
            "Maria Altagracia Peralta","Jose Ramon Tavarez","Ana Luisa Fermin","Pedro Antonio Cruz",
            "Rosa Elena Bencosme","Juan Carlos Rodriguez","Carmen Dilia Vasquez","Luis Manuel Espinal",
            "Yudelka Marte Rosario","Francisco Alberto Nunez","Mercedes Paulino","Ramon Emilio Grullon",
            "Altagracia Jimenez","Domingo Antonio Reyes","Sonia Margarita Lora","Rafael Andres Guzman",
            "Josefina Batista","Miguel Angel Fernandez","Elsa Maria Ureña","Antonio de Jesus Diaz",
            "Colmado El Progreso","Cafeteria Dona Tita","Comedor La Sazon","Salon Bella Imagen",
            "Ferreteria Los Hermanos","Escuela Basica Moca","Junta de Vecinos La Loma","Farmacia San Rafael",
            "Yaneiry Almonte","Wilkin Rodriguez","Deivi Santana","Massiel Perez",
            "Onelio Gomez","Brenda Liz Castillo","Genaro Abreu","Iluminada Santos",
            "Kelvin Mateo","Nurys Delgado","Higinio Polanco","Robert Cabrera"
        };
        for (int i = 0; i < nombres.Length; i++)
        {
            bool conCredito = i < 18;                    // 18 con credito
            bool creditoFiscal = i is >= 20 and <= 27;   // negocios con RNC
            l.Clientes.Add(new Cliente
            {
                Id = l.SiguienteId(),
                Codigo = $"CLI-{i + 1:000}",
                Nombre = nombres[i],
                TipoDocumento = creditoFiscal ? TipoDocumento.Rnc : (i % 3 == 0 ? TipoDocumento.Cedula : TipoDocumento.Ninguno),
                NumeroDocumento = creditoFiscal ? $"1310{i:00000}" : (i % 3 == 0 ? $"0540{i:0000000}" : null),
                TipoComprobante = creditoFiscal ? TipoComprobante.CreditoFiscal : TipoComprobante.Consumo,
                LimiteCredito = conCredito ? ((i % 4) switch { 0 => 3000m, 1 => 5000m, 2 => 1500m, _ => 8000m }) : 0m,
                DiasCredito = conCredito ? 15 : 0,
                Telefono = $"809-578-{1000 + i:0000}",
                Activo = i != 39,                        // uno inactivo a proposito
                BalanceActual = 0m,
                CreadoPor = Admin
            });
        }
    }
}
