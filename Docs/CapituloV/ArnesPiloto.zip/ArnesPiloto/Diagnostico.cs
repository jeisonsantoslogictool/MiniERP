using MiniERP.Domain.Inventario;
using MiniERP.Domain.Shared;
using MiniERP.Domain.Ventas;
using MiniERP.Domain.Clientes;
using MiniERP.Domain.Compras;

namespace Piloto;

/// <summary>Aisla y demuestra los hallazgos detectados por los cuadres.</summary>
public static class Diagnostico
{
    public static string Ejecutar()
    {
        var sb = new System.Text.StringBuilder();
        void W(string s = "") => sb.AppendLine(s);

        W("================================================================================");
        W("  DIAGNOSTICO DE LOS CUADRES FALLIDOS");
        W("================================================================================");
        W();

        // ---------------------------------------------------------------- HALLAZGO 1
        W("--- D-01: venta de un producto que no maneja inventario ---");
        var servicio = new Producto
        {
            Id = 500, Codigo = "S001", Descripcion = "Recarga telefonica",
            PrecioVenta = 100m, TasaItbis = 0.18m, ManejaInventario = false, Activo = true
        };
        var f = new Factura { Id = 900, Numero = "F-SERV", Fecha = new DateTime(2026, 6, 1) };
        f.Lineas.Add(new LineaFactura
        {
            Id = 901, FacturaId = 900, ProductoId = servicio.Id,
            Descripcion = servicio.Descripcion, Cantidad = 3, PrecioUnitario = 100m, TasaItbis = 0.18m
        });
        var movs = f.Emitir(new Dictionary<int, Producto> { [servicio.Id] = servicio }, "B0200000001", "cajero@x.do");

        W($"Producto vendido ............ {servicio.Descripcion} (ManejaInventario = {servicio.ManejaInventario})");
        W($"Cantidad vendida ............ {f.Lineas.First().Cantidad}");
        W($"Movimientos que Emitir devuelve para persistir: {movs.Count}");
        foreach (var m in movs)
        {
            W($"  Tipo ...................... {m.Tipo}");
            W($"  ProductoId ................ {m.ProductoId}   <-- deberia ser {servicio.Id}");
            W($"  Cantidad .................. {m.Cantidad}");
            W($"  ExistenciaAnterior ........ {m.ExistenciaAnterior}");
            W($"  ExistenciaResultante ...... {m.ExistenciaResultante}");
            W($"  ReferenciaTipo/Id ......... {m.ReferenciaTipo}/{m.ReferenciaId}");
        }
        W();
        W("Causa: Producto.AplicarMovimiento hace 'if (!ManejaInventario) return;' ANTES de");
        W("asignar movimiento.ProductoId, por lo que el movimiento sale con ProductoId = 0.");
        W("Factura.Emitir lo agrega igualmente a la lista que devuelve, y VentaService la");
        W("entrega a AgregarMovimientos + GuardarAsync sin filtrarla.");
        W();
        W("Consecuencia en produccion: MovimientosInventario.ProductoId es NOT NULL con clave");
        W("foranea restringida hacia Productos. Insertar ProductoId = 0 viola la restriccion,");
        W("SaveChanges lanza y la transaccion revierte la venta completa.");
        W($"Total de la factura que se perderia: RD$ {f.Total:N2}");
        W();

        // ---------------------------------------------------------------- HALLAZGO 2
        W("--- D-02: recepcion de una compra que incluye un servicio ---");
        var servicio2 = new Producto
        {
            Id = 501, Codigo = "S002", Descripcion = "Fotocopia",
            PrecioVenta = 5m, ManejaInventario = false, Activo = true
        };
        var c = new Compra { Id = 910, Numero = "COM-SERV", Fecha = new DateTime(2026, 6, 1) };
        c.Lineas.Add(new LineaCompra
        {
            Id = 911, CompraId = 910, ProductoId = servicio2.Id,
            Descripcion = servicio2.Descripcion, Cantidad = 10, CostoUnitario = 2m, TasaItbis = 0.18m
        });
        c.Recalcular();
        var movsC = c.Recibir(new Dictionary<int, Producto> { [servicio2.Id] = servicio2 }, "almacen@x.do");
        W($"Movimientos devueltos ....... {movsC.Count}");
        W($"ProductoId del movimiento ... {movsC[0].ProductoId}   <-- deberia ser {servicio2.Id}");
        W($"Costo del servicio tras recibir: {servicio2.Costo}  (CalcularCostoPromedio devuelve el costo recibido)");
        W();

        // ---------------------------------------------------------------- HALLAZGO 3
        W("--- D-03: efecto sobre la anulacion de una factura con servicio ---");
        var movsAnul = f.Anular(new Dictionary<int, Producto> { [servicio.Id] = servicio }, "prueba", "sup@x.do");
        W($"Movimientos de reposicion ... {movsAnul.Count}");
        W($"ProductoId del movimiento ... {movsAnul[0].ProductoId}   <-- tampoco se asigna");
        W("La anulacion arrastra el mismo defecto: el asiento de vuelta queda huerfano.");
        W();

        // ---------------------------------------------------------------- CONTROL
        W("--- D-04: control, el mismo flujo con un producto que si maneja inventario ---");
        var normal = new Producto
        {
            Id = 502, Codigo = "P001", Descripcion = "Arroz selecto",
            PrecioVenta = 35m, TasaItbis = 0m, Costo = 26.5m, Existencia = 100m, ManejaInventario = true, Activo = true
        };
        var f2 = new Factura { Id = 920, Numero = "F-NORM", Fecha = new DateTime(2026, 6, 1) };
        f2.Lineas.Add(new LineaFactura { Id = 921, FacturaId = 920, ProductoId = normal.Id, Descripcion = normal.Descripcion, Cantidad = 5, PrecioUnitario = 35m, TasaItbis = 0m });
        var movs2 = f2.Emitir(new Dictionary<int, Producto> { [normal.Id] = normal }, "B0200000002", "cajero@x.do");
        W($"ProductoId ................. {movs2[0].ProductoId}");
        W($"ExistenciaAnterior ......... {movs2[0].ExistenciaAnterior}");
        W($"ExistenciaResultante ....... {movs2[0].ExistenciaResultante}");
        W($"Existencia del producto .... {normal.Existencia}");
        W("El flujo normal es correcto: el defecto se limita a los productos sin inventario.");
        W();

        return sb.ToString();
    }
}
